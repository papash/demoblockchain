process.env.GOPATH = __dirname;

//Hyperledger Fabric Client SDK for Node.js (SDK-Demo\node_modules\hfc)
var hfc = require('hfc');
var util = require('util');
var fs = require('fs');
var ws = require('ws');
var Ibc1 = require('ibm-blockchain-js'); // doc https://github.com/IBM-Blockchain/ibm-blockchain-js#ibcjs
var ibc = new Ibc1();
const https = require('https');

var config;
var chain;
var network;
var certPath;
var peers;
var users;
var userObj;
var newUserName;
var chaincodeID;
var certFile = 'us.blockchain.ibm.com.cert';
var chaincodeIDPath = __dirname + "/chaincodeID";
var chaincode = null;


var caUrl;
var peerUrls = [];
var EventUrls = [];

init();
//setup();
//creaNodo();
//obtieneNodo();
//registraChaincode();
//consulta();
//creaPersona();

//Inicializaci�n de la aplicaci�n. Este es el primer metodo invocado.
function init() {
	var manual = JSON.parse(fs.readFileSync(__dirname + '/ServiceCredentials.json', 'utf8'));
	peers = manual.peers;
	console.log('loading hardcoded peers');
	if(manual.users) users = manual.users;
	console.log('loading hardcoded users');

	var options = 	{
						network:{
							peers: [peers[0]],																	//lets only use the first peer! since we really don't need any more than 1
							users: prefer_type1_users(users),													//dump the whole thing, sdk will parse for a good one
							options: {
										quiet: true, 															//detailed debug messages on/off true/false
										tls: detect_tls_or_not(peers), 											//should app to peer communication use tls?
										maxRetry: 1																//how many times should we retry register before giving up
									}
						},
						chaincode:{
							zip_url: 'https://github.com/papash/demoblockchain/raw/master/chaincode_example_personas.zip',
							unzip_dir: 'chaincode',													//subdirectroy name of chaincode after unzipped
							git_url: 'https://github.com/papash/demoblockchain',						//GO get http url
							//hashed cc name from prev deployment, comment me out to always deploy, uncomment me when its already deployed to skip deploying again
							deployed_name: '4b3575a9c550994a54bce9397972b5d0444efa691405ef024656645daeec86a7'
						}
				};

	ibc.load(options, function (err, cc){														//parse/load chaincode, response has chaincode functions!
		if(err != null){
			console.log('! looks like an error loading the chaincode or network, app will fail\n', err);
			if(!process.error) process.error = {type: 'load', msg: err.details};				//if it already exist, keep the last error
		}
		else{
			chaincode = cc;

			// ---- To Deploy or Not to Deploy ---- //
			if(!cc.details.deployed_name || cc.details.deployed_name === ''){					//yes, go deploy
				cc.deploy('init', ['99'], {delay_ms: 60000}, function(e){ 						//delay_ms is milliseconds to wait after deploy for conatiner to start, 50sec recommended
					console.log("Revisar en bluemix si se desplego el chaincode...")
				});
			}
			else{																				//no, already deployed
				console.log('Chaincode ya se ha desplegado anteriormente...');
			}

			chaincode.query.read(["ful123"], function(e, persona) {
				if(e != null) console.log('No se pudo obtener la persona:', e);
				else {
					if(persona) console.log(persona);
				}
			});
		}
	});


}

//filter for type1 users if we have any
function prefer_type1_users(user_array){
	var ret = [];
	for(var i in users){
		if(users[i].enrollId.indexOf('type1') >= 0) {	//gather the type1 users
			ret.push(users[i]);
		}
	}

	if(ret.length === 0) ret = user_array;				//if no users found, just use what we have
	return ret;
}

//see if peer 0 wants tls or no tls
function detect_tls_or_not(peer_array){
	var tls = false;
	if(peer_array[0] && peer_array[0].api_port_tls){
		if(!isNaN(peer_array[0].api_port_tls)) tls = true;
	}
	return tls;
}

//Registra usuarios en la red de blockchain y despliega el chaincode.
function creaNodo() {

    // Registramos al usuario admin.
    // La variable chain se inicializ� con la referencia a la red de blockchain.
    chain.enroll(users[0].enrollId, users[0].enrollSecret, function(err, admin) {
        if (err) throw Error("\nERROR: failed to enroll admin : " + err);

        console.log("\nEnrolled admin sucecssfully");

        // Set this user as the chain's registrar which is authorized to register other users.
        chain.setRegistrar(admin);

        //Registramos al usuario JohnDoe definido en el archivo config.json
        var registrationRequest = {
            enrollmentID: newUserName,
            affiliation: config.user.affiliation
        };
        chain.registerAndEnroll(registrationRequest, function(err, user) {
            if (err) throw Error(" Failed to register and enroll " + newUserName + ": " + err);

            console.log("\nEnrolled and registered " + newUserName + " successfully");
            process.exit(1);
        });
    });
}

//Registra usuarios en la red de blockchain y despliega el chaincode.
function obtieneNodo() {
	//Obtenemos el usuario admin con el que vamos a desplegar el chaincode.
	chain.getUser("Banorte", function(err, user) {
		if (err) throw Error(" No se pudo obtener al usuario " + user + ": " + err);
		console.log("\nUsuario " + user + " obtenido correctamente");
		process.exit(1);
	});
}

//Registra chaincode en blockchain
function registraChaincode(){
	var args = getArgs(config.deployRequest);
	var usuarioAdmin;
	var chaincodeID;

	// Generamos el request para desplegar el chaincode en la red de blockchain.
	var deployRequest = {
		// La funcion del chaincode a invocar esta definida en config.json y establece la inicializacion de los
		// assets utilizados en este ejemplo, que son 'a' y 'b', con un valor de 100 y 200 respectivamente.
		fcn: config.deployRequest.functionName,
		// Arguments to the initializing function
		args: args,
		//La ruta donde se encuentra nuestro codigo fuente de chaincode que se quiere desplegar en la red.
		chaincodePath: config.deployRequest.chaincodePath,
		// the location where the startup and HSBN store the certificates
		certificatePath: network.cert_path
	};

	//Mostramos el request en consola.
	console.log("\ndeployRequest = %j", deployRequest);

	chain.setDeployWaitTime(120);

	//Obtenemos el usuario admin con el que vamos a desplegar el chaincode.
	chain.getUser("admin", function(err, user) {
		if (err) throw Error(" No se pudo obtener al usuario " + user + ": " + err);
		console.log("\nUsuario " + user + " obtenido correctamente para despliegue de chaincode");
		usuarioAdmin = user;
		// Desplegamos el chaincode en la red de blockchain.
		console.log("\nDesplegando chaincode...");
		var deployTx = usuarioAdmin.deploy(deployRequest);
	});
}

//Obtiene usuario de la red de blockchain.
function consulta(){
	chaincodeID = "b5d2fe8099a33c0a6b831e288ec216c8689f5e04f21c8f10b96603b4b8826083"; //Reemplazar el ID por el generado en el Dashboard de Blockchain en Bluemix.
	//El request del query se encuentra definido en config.json y consulta el valor de 'a'.
	var args = getArgs(config.queryRequest);
	// Construct the query request
	var queryRequest = {
		// Name (hash) required for query
		chaincodeID: chaincodeID,
		// Function to trigger
		fcn: config.queryRequest.functionName,
		// Existing state variable to retrieve
		args: args
    };
	//Obtenemos el usuario
	chain.getUser("Banorte", function(err, user) {
		if (err) throw Error(" No se pudo obtener al usuario " + user + ": " + err);
		console.log("\nUsuario " + user + " obtenido correctamente para consulta");
		console.log("\nConsultando...");
		var queryTx = user.query(queryRequest);
        // Print the query results
		queryTx.on('complete', function(results) {
			// Query completed successfully
			console.log("\nSuccessfully queried  chaincode function: request=%j, value=%s", queryRequest, results.result.toString());
			process.exit(0);
		});
		queryTx.on('error', function(err) {
			// Query failed
			console.log("\nFailed to query chaincode, function: request=%j, error=%j", queryRequest, err);
			process.exit(1);
    	});
	});
}

//Obtiene usuario de la red de blockchain.
function creaPersona(){
	chaincodeID = "b5d2fe8099a33c0a6b831e288ec216c8689f5e04f21c8f10b96603b4b8826083"; //Reemplazar el ID por el generado en el Dashboard de Blockchain en Bluemix.
	//El request del query se encuentra definido en config.json y consulta el valor de 'a'.
	var args = getArgs(config.invokeRequest);
	// Construct the query request
	var invokeRequest = {
		// Name (hash) required for query
		chaincodeID: chaincodeID,
		// Function to trigger
		fcn: config.invokeRequest.functionName,
		// Existing state variable to retrieve
		args: args
    };
	//Obtenemos el usuario
	chain.getUser("Banorte", function(err, user) {
		if (err) throw Error(" No se pudo obtener al usuario " + user + ": " + err);
		console.log("\nUsuario " + user + " obtenido correctamente para consulta");
		console.log("\nInvocando...");
		// Trigger the invoke transaction
    	var invokeTx = user.invoke(invokeRequest);
        // Print the query results
		invokeTx.on('complete', function(results) {
			// Query completed successfully
			console.log(util.format("\nSuccessfully completed chaincode invoke transaction: request=%j, response=%j", invokeRequest, results));
			process.exit(0);
		});
		invokeTx.on('error', function(err) {
			// Query failed
			console.log(util.format("\nFailed to submit chaincode invoke transaction: request=%j, error=%j", invokeRequest, err));
			process.exit(1);
    	});
	});
}

function getArgs(request) {
    var args = [];
    for (var i = 0; i < request.args.length; i++) {
        args.push(request.args[i]);
    }
    return args;
}