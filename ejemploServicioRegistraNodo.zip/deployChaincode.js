process.env.GOPATH = __dirname;

//Hyperledger Fabric Client SDK for Node.js (SDK-Demo\node_modules\hfc)
var hfc = require('hfc');
var util = require('util');
var fs = require('fs');
const https = require('https');

var config;
var chain;
var network;
var certPath;
var peers;
var users;
var userObj;
var newUserName;
var chaincodeID;
var certFile = 'us.blockchain.ibm.com.cert';
var chaincodeIDPath = __dirname + "/chaincodeID";


var caUrl;
var peerUrls = [];
var EventUrls = [];

init();
setup();
registraChaincode();

//Inicializaci�n de la aplicaci�n. Este es el primer metodo invocado.
function init() {
	try {
		//Cargamos la configuraci�n del archivo config.json
		config = JSON.parse(fs.readFileSync(__dirname + '/config.json', 'utf8'));
	} catch (err) {
		console.log("config.json is missing or invalid file, Rerun the program with right file")
		process.exit();
	}

	// Creamos un blockchain llamado "hello-world". El API para trabajar con el chaincode, mediante la variable chain, se encuentra
	// en https://github.com/hyperledger/fabric-sdk-node/blob/master/docs/index.md
	chain = hfc.newChain(config.chainName);
	//Ruta del certificado a utilizar en la red de blockchain
	certPath = __dirname + "/certificate.pem";

	// Leemos las credenciales de nuestra red de blockchain, contenidas en ServiceCredentials.json
	try {
		network = JSON.parse(fs.readFileSync(__dirname + '/ServiceCredentials.json', 'utf8'));
		if (network.credentials) network = network.credentials;
	} catch (err) {
		console.log("ServiceCredentials.json is missing or invalid file, Rerun the program with right file")
		process.exit();
	}

	//Nodos de validaci�n de la red de blockchain. Al crear la instancia en Bluemix, nos asignan 4 nodos. Se pueden ver en el Dashboard.
	peers = network.peers;

	//Nodos que van a interactuar dentro de la red de blockchain, para el intercambio de informaci�n.
	users = network.users;
}

function setup() {
	// HSBN = High Security Business Network. En caso de ser una red de este tipo, necesitamos un certificado de seguridad para
	// operar en ella.
    // Determining if we are running on a startup or HSBN network based on the url
    // of the discovery host name.  The HSBN will contain the string zone.
    var isHSBN = peers[0].discovery_host.indexOf('secure') >= 0 ? true : false;
    var network_id = Object.keys(network.ca);
    caUrl = "grpcs://" + network.ca[network_id].discovery_host + ":" + network.ca[network_id].discovery_port;

    // Configure the KeyValStore which is used to store sensitive keys.
    // This data needs to be located or accessible any time the users enrollmentID
    // perform any functions on the blockchain.  The users are not usable without
    // This data.
    var uuid = network_id[0].substring(0, 8);
    chain.setKeyValStore(hfc.newFileKeyValStore(__dirname + '/keyValStore-' + uuid));

    if (isHSBN) {
        certFile = '0.secure.blockchain.ibm.com.cert';
    }
    fs.createReadStream(certFile).pipe(fs.createWriteStream(certPath));
    var cert = fs.readFileSync(certFile);

    chain.setMemberServicesUrl(caUrl, {
        pem: cert
    });

    peerUrls = [];
    eventUrls = [];
    // Adding all the peers to blockchain
    // this adds high availability for the client
    for (var i = 0; i < peers.length; i++) {
        // Peers on Bluemix require secured connections, hence 'grpcs://'
        peerUrls.push("grpcs://" + peers[i].discovery_host + ":" + peers[i].discovery_port);
        chain.addPeer(peerUrls[i], {
            pem: cert
        });
        eventUrls.push("grpcs://" + peers[i].event_host + ":" + peers[i].event_port);
        chain.eventHubConnect(eventUrls[0], {
            pem: cert
        });
    }

    //Inicializa el usuario con el que vamos a trabajar con la red de Blockchain y que est� definido
    //en config.json
    newUserName = config.user.username;

    // Make sure disconnect the eventhub on exit
    process.on('exit', function() {
        chain.eventHubDisconnect();
    });
}

//Registra chaincode en blockchain
function registraChaincode(){
	var args = getArgs(config.deployRequest);
	var usuarioAdmin;
	var chaincodeID;

	// Generamos el request para desplegar el chaincode en la red de blockchain.
	var deployRequest = {
		// La funcion del chaincode a invocar esta definida en config.json y establece la inicializacion de los
		// assets utilizados en este ejemplo, que son 'a' y 'b', con un valor de 100 y 200 respectivamente.
		fcn: config.deployRequest.functionName,
		// Arguments to the initializing function
		args: args,
		//La ruta donde se encuentra nuestro codigo fuente de chaincode que se quiere desplegar en la red.
		chaincodePath: config.deployRequest.chaincodePath,
		// the location where the startup and HSBN store the certificates
		certificatePath: network.cert_path
	};

	//Mostramos el request en consola.
	console.log("\ndeployRequest = %j", deployRequest);

	chain.setDeployWaitTime(120);

	// Registramos al usuario admin.
	// La variable chain se inicializ� con la referencia a la red de blockchain.
	chain.enroll(users[0].enrollId, users[0].enrollSecret, function(err, admin) {
		if (err) throw Error("\nERROR: failed to enroll admin : " + err);

		console.log("\nEnrolled admin sucecssfully");

		// Set this user as the chain's registrar which is authorized to register other users.
		chain.setRegistrar(admin);

		//Obtenemos el usuario admin con el que vamos a desplegar el chaincode.
		chain.getUser("admin", function(err, user) {
			if (err) throw Error(" No se pudo obtener al usuario " + user + ": " + err);
			console.log("\nUsuario " + user + " obtenido correctamente para despliegue de chaincode");
			usuarioAdmin = user;
			// Desplegamos el chaincode en la red de blockchain.
			console.log("\nDesplegando chaincode...");
			var deployTx = usuarioAdmin.deploy(deployRequest);
		});
    });


}

function getArgs(request) {
    var args = [];
    for (var i = 0; i < request.args.length; i++) {
        args.push(request.args[i]);
    }
    return args;
}